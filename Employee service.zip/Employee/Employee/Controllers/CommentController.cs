﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EmployeeDAL;
using Entities;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;

namespace Employee.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CommentController : ControllerBase
    {
        IConfiguration configuration;
        public CommentController(IConfiguration config)
        {
            configuration = config;
        }

        [HttpGet]
        [Route("GetAllComments/{employeeID}/{commentTypeID}")]
        public IActionResult GetAllComments(int employeeID, int commentTypeID)
        {
            try
            {
                DalEmployee dal = new DalEmployee(this.configuration.GetConnectionString("EmployeeConnection"));
                var result = dal.GetComments(employeeID, commentTypeID);

                return Ok(result);
            }
            catch (Exception ex)
            {
                return BadRequest($"The service Failed with message: {ex.ToString()}");
            }
        }

        [HttpPost]
        [Route("InsertComment")]
        public IActionResult InsertComment([FromBody] DtoComment comment)
        {
            try
            {
                DalEmployee dal = new DalEmployee(this.configuration.GetConnectionString("EmployeeConnection"));
                dal.InsertComment(comment);

                return Ok("Comment Inserted Successfully!");
            }
            catch (Exception ex)
            {
                return BadRequest($"The service Failed with message: {ex.ToString()}");
            }
        }
    }
}