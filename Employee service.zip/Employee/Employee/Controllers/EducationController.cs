﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EmployeeDAL;
using Entities;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;

namespace Employee.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EducationController : ControllerBase
    {
        IConfiguration configuration;
        public EducationController(IConfiguration config)
        {
            configuration = config;
        }

        [HttpGet]
        [Route("GetEducationDetails/{EmployeeID}")]
        public IActionResult GetEducationDetails(int employeeID)
        {
            try
            {
                DalEmployee dal = new DalEmployee(this.configuration.GetConnectionString("EmployeeConnection"));
                var result = dal.GetEducationDetailsByEmployeeID(employeeID);

                return Ok(result);
            }
            catch (Exception ex)
            {
                return BadRequest($"The service Failed with message: {ex.ToString()}");
            }
        }

        [HttpPut]
        [Route("InsertEducationDetails")]
        public IActionResult InsertPersonalDetails([FromBody] DtoEducationDetails input)
        {
            try
            {
                DalEmployee dal = new DalEmployee(this.configuration.GetConnectionString("EmployeeConnection"));
                dal.InsertEducationDetails(input);

                return Ok("API Executed Successfuly!");
            }
            catch (Exception ex)
            {
                return BadRequest($"The service Failed with message: {ex.ToString()}");
            }
        }
    }
}