﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using EmployeeDAL;
using Entities;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;

namespace Employee.Controllers
{
    [Route("Employee")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        IConfiguration configuration;
        public EmployeeController(IConfiguration config)
        {
            configuration = config;
        }

        [HttpGet]
        [Route("GetAllEmployee")]
        public IActionResult GetAllEmployees()
        {
            try
            {
                DalEmployee dal = new DalEmployee(this.configuration.GetConnectionString("EmployeeConnection"));
                var result = dal.GetAllEmployees();

                return Ok(result);
            }
            catch (Exception ex)
            {
                return BadRequest($"The service Failed with message: {ex.ToString()}");
            }
        }

        [HttpPost]
        [Route("InsertEmployee")]
        public IActionResult InsertEmployees([FromBody] DtoEmployee employee)
        {
            try
            {
                DalEmployee dal = new DalEmployee(this.configuration.GetConnectionString("EmployeeConnection"));
                dal.InsertEmployeeDetails(employee);

                return Ok("Employee Inserted Successfully!");
            }
            catch (Exception ex)
            {
                return BadRequest($"The service Failed with message: {ex.ToString()}");
            }
        }
    }
}