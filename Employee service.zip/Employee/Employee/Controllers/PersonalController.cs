﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EmployeeDAL;
using Entities;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;

namespace Employee.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PersonalController : ControllerBase
    {
        IConfiguration configuration;
        public PersonalController(IConfiguration config)
        {
            configuration = config;
        }

        [HttpGet]
        [Route("GetPersonalDetails/{EmployeeID}")]
        public IActionResult GetPersonalDetails(int employeeID)
        {
            try
            {
                DalEmployee dal = new DalEmployee(this.configuration.GetConnectionString("EmployeeConnection"));
                var result = dal.GetPersonalDetailsByEmployeeID(employeeID);

                return Ok(result);
            }
            catch (Exception ex)
            {
                return BadRequest($"The service Failed with message: {ex.ToString()}");
            }
        }

        [HttpPut]
        [Route("InsertPersonalDetails")]
        public IActionResult InsertPersonalDetails([FromBody] DtoPersonalDetails input)
        {
            try
            {
                DalEmployee dal = new DalEmployee(this.configuration.GetConnectionString("EmployeeConnection"));
                dal.InsertPersonalDetails(input);

                return Ok("API Executed Successfuly!");
            }
            catch (Exception ex)
            {
                return BadRequest($"The service Failed with message: {ex.ToString()}");
            }
        }
    }
}