﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using Dapper;
using Entities;

namespace EmployeeDAL
{
    public class DalEmployee
    {
        private readonly string ConnectionString;
        public DalEmployee(string connectionString)
        {
            ConnectionString = connectionString;
        }

        public IList<DtoEmployee> GetAllEmployees()
        {
            try
            {
                using (IDbConnection db = new SqlConnection(ConnectionString))
                {
                    var result = db.Query<DtoEmployee>("EmployeeGetAll", commandType: CommandType.StoredProcedure).AsList();

                    return result;
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public void InsertEmployeeDetails(DtoEmployee employee)
        {
            try
            {
                using (IDbConnection db = new SqlConnection(ConnectionString))
                {
                    var result = db.Execute("EmployeeInsert", new
                    {
                        EmployeeNumber = employee.EmployeeNumber,
                        FirstName = employee.FirstName,
                        MiddleName = employee.MiddleName,
                        LastName = employee.LastName,
                        EmailAddress = employee.EmailAddress,
                        PersonalEmailID = employee.PersonalEmailID,
                        MobileNumber = employee.MobileNumber,
                        IsEmployee = employee.IsEmployee,
                        IsActive = employee.IsActive,
                        CreatedByID = employee.CreatedByID,
                        ModifiedByID = employee.ModifiedByID
                    }, commandType: CommandType.StoredProcedure);
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public void InsertPersonalDetails(DtoPersonalDetails personalDetails)
        {
            try
            {
                using (IDbConnection db = new SqlConnection(ConnectionString))
                {
                    var result = db.Execute("PersonalDetailsInsert", new
                    {
                        EmployeeID = personalDetails.EmployeeID,
                        NameAsPerAADHAAR = personalDetails.NameAsPerAADHAAR,
                        FatherName = personalDetails.FatherName,
                        DOB = personalDetails.DateOfBirth,
                        MobileNumber = personalDetails.MobileNumber,
                        PanNumber = personalDetails.PanNumber,
                        PanAttachment = personalDetails.PanAttachment,
                        PassportNumber = personalDetails.PanNumber,
                        PassportAttachment = personalDetails.PassportAttachment,
                        AadhaarNumber = personalDetails.AadhaarNumber,
                        AadhaarAttachment = personalDetails.AadhaarAttachment,
                        CreatedByID = personalDetails.CreatedByID,
                        ModifiedByID = personalDetails.ModifiedByID
                    }, commandType: CommandType.StoredProcedure);
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public DtoPersonalDetails GetPersonalDetailsByEmployeeID(int employeeID)
        {
            try
            {
                using (IDbConnection db = new SqlConnection(ConnectionString))
                {
                    var result = db.QueryFirstOrDefault<DtoPersonalDetails>("PersonalDetailsGetByEmployeeID", new { EmployeeID = employeeID }, commandType: CommandType.StoredProcedure);

                    return result;
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public IList<DtoEducationDetails> GetEducationDetailsByEmployeeID(int employeeID)
        {
            try
            {
                using (IDbConnection db = new SqlConnection(ConnectionString))
                {
                    var result = db.QueryFirstOrDefault<IList<DtoEducationDetails>>("EducationDetailsGetByEmployeeID", new { EmployeeID = employeeID }, commandType: CommandType.StoredProcedure);

                    return result;
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public void InsertEducationDetails(DtoEducationDetails educationDetails)
        {
            try
            {
                using (IDbConnection db = new SqlConnection(ConnectionString))
                {
                    var result = db.Execute("EducationDetailsInsert", new
                    {
                        EmployeeID = educationDetails.EmployeeID,
                        CourseName = educationDetails.CourseName,
                        RegistrationNumber = educationDetails.RegistrationNumber,
                        Specialization = educationDetails.Specialization,
                        YearOfPassing = educationDetails.YearOfPassing,
                        InstituteName = educationDetails.InstituteName,
                        InstituteAddress = educationDetails.InstituteName,
                        InstituteCity = educationDetails.InstituteCity,
                        CollegePinCode = educationDetails.CollegePinCode,
                        UniversityAddress = educationDetails.UniversityAddress,
                        UniversityCity = educationDetails.UniversityCity,
                        UniversityPinCode = educationDetails.UniversityPinCode,
                        CreatedByID = educationDetails.CreatedByID,
                        ModifiedByID = educationDetails.ModifiedByID
                    }, commandType: CommandType.StoredProcedure);
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public IList<DtoEmployementDetails> GetEmploymentDetailsByEmployeeID(int employeeID)
        {
            try
            {
                using (IDbConnection db = new SqlConnection(ConnectionString))
                {
                    var result = db.QueryFirstOrDefault<IList<DtoEmployementDetails>>("EmployementDetailsGetByEmployeeID", new { EmployeeID = employeeID }, commandType: CommandType.StoredProcedure);

                    return result;
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public void InsertEmploymentDetails(DtoEmployementDetails employmentDetails)
        {
            try
            {
                using (IDbConnection db = new SqlConnection(ConnectionString))
                {
                    var result = db.Execute("EmployementDetailsInsert", new
                    {
                        EmployeeID = employmentDetails.EmployeeID,
                        CompanyName = employmentDetails.CompanyName,
                        Address = employmentDetails.Address,
                        City = employmentDetails.City,
                        PinCode = employmentDetails.PinCode,
                        Website = employmentDetails.Website,
                        LandlineNumber = employmentDetails.LandlineNumber,
                        EmployeeNumber = employmentDetails.EmployeeNumber,
                        Designation = employmentDetails.Designation,
                        Department = employmentDetails.Department,
                        JoiningDate = employmentDetails.JoiningDate,
                        RelievingDate = employmentDetails.RelievingDate,
                        IsFullTimeEmployee = employmentDetails.IsFullTimeEmployee,
                        NetMonthlySalary = employmentDetails.NetMonthlySalary,
                        ManagerName = employmentDetails.ManagerName,
                        ManagerDesignation = employmentDetails.ManagerDesignation,
                        ManagerContactNumber = employmentDetails.ManagerContactNumber,
                        ManagerEmailID = employmentDetails.ManagerEmailID,
                        HrManagerName = employmentDetails.HrManagerName,
                        HrContactNumber = employmentDetails.HrContactNumber,
                        HrEmailID = employmentDetails.HrEmailID,
                        OfferLetterAttachment = employmentDetails.OfferLetterAttachment,
                        RelievingLetterAttachment = employmentDetails.RelievingLetterAttachment,
                        ExperienceCertificateAttachment = employmentDetails.ExperienceCertificateAttachment,
                        Payslip1Attachment = employmentDetails.Payslip1Attachment,
                        Payslip2Attachment = employmentDetails.Payslip2Attachment,
                        Payslip3Attachment = employmentDetails.Payslip3Attachment,
                        CreatedByID = employmentDetails.CreatedByID,
                        ModifiedByID = employmentDetails.ModifiedByID
                    }, commandType: CommandType.StoredProcedure);
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public IList<DtoInsuranceDetails> GetInsuranceDetailsByEmployeeID(int employeeID)
        {
            try
            {
                using (IDbConnection db = new SqlConnection(ConnectionString))
                {
                    var result = db.QueryFirstOrDefault<IList<DtoInsuranceDetails>>("InsuranceDetailsGetByEmployeeID", new { EmployeeID = employeeID }, commandType: CommandType.StoredProcedure);

                    return result;
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public void InsertInsuranceDetails(DtoInsuranceDetails insuranceDetails)
        {
            try
            {
                using (IDbConnection db = new SqlConnection(ConnectionString))
                {
                    var result = db.Execute("InsuranceDetailsInsert", new
                    {
                        EmployeeID = insuranceDetails.EmployeeID,
                        RelationshipType = insuranceDetails.RelationshipWithInsurerType,
                        Name = insuranceDetails.Name,
                        Gender = insuranceDetails.Gender,
                        MobileNumber = insuranceDetails.MobileNumber,
                        DateOfBirth = insuranceDetails.DateOfBirth,
                        RelationshipWithProposer = insuranceDetails.RelationshipWithProposer,
                        MaritalStatus = insuranceDetails.MaritalStatus,
                        IsActive = insuranceDetails.IsActive,
                        CreatedByID = insuranceDetails.CreatedByID,
                        ModifiedByID = insuranceDetails.ModifiedByID
                    }, commandType: CommandType.StoredProcedure);
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public IList<DtoComment> GetComments(int employeeID, int? commentTypeID)
        {
            try
            {
                using (IDbConnection db = new SqlConnection(ConnectionString))
                {
                    var result = db.QueryFirstOrDefault<IList<DtoComment>>("CommentGetAll", new { EmployeeID = employeeID, CommentTypeID = commentTypeID.Value }, commandType: CommandType.StoredProcedure);

                    return result;
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public void InsertComment(DtoComment comment)
        {
            try
            {
                using (IDbConnection db = new SqlConnection(ConnectionString))
                {
                    var result = db.Execute("CommentInsert", new
                    {
                        EmployeeID = comment.EmployeeID,
                        CommentTypeID = comment.CommentTypeID,
                        CommentDescription = comment.CommentDescription,
                        CreatedByID = comment.CommentTypeID
                    }, commandType: CommandType.StoredProcedure);
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }

    }
}
