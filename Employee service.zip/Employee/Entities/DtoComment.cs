﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entities
{
    public class DtoComment
    {
        public DtoComment()
        {

        }

        public int CommentID { get; set; }
        public int CommentTypeID { get; set; }
        public int EmployeeID { get; set; }
        public string CommentDescription { get; set; }
        public int CreatedByID { get; set; }
        public DateTime CreatedByDate { get; set; }		
    }
}
