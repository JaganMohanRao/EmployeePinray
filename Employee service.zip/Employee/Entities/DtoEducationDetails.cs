﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entities
{
    enum EducationType
    {
        SSLC = 1,
        PUC = 2,
        Degree = 3,
        Masters = 4
    }

    public class DtoEducationDetails
    {
        public DtoEducationDetails()
        {

        }

        public int EducationDetailID { get; set; }
        public int EmployeeID { get; set; }
        public string CourseName { get; set; }
        public string RegistrationNumber { get; set; }
        public string Specialization { get; set; }
        public int YearOfPassing { get; set; }
        public string InstituteName { get; set; }
        public string InstituteAddress { get; set; }
        public string InstituteCity { get; set; }
        public int CollegePinCode { get; set; }
        public string UniversityAddress { get; set; }
        public string UniversityCity { get; set; }
        public int? UniversityPinCode { get; set; }
        public int? CreatedByID { get; set; }
        public DateTime CreateDate { get; set; }
        public int ModifiedByID { get; set; }
        public DateTime ModifiedDate { get; set; }
    }
}
