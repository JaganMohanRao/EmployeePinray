﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entities
{
   public class DtoEmployee
    {
        public DtoEmployee()
        {

        }

        public int EmployeeID { get; set; }
        public string EmployeeNumber { get; set; }
        public string FirstName { get; set; }
        public string MiddleName { get; set; }
        public string LastName { get; set; }
        public string EmailAddress { get; set; }
        public string PersonalEmailID { get; set; }
        public string MobileNumber { get; set; }
        public bool IsEmployee { get; set; }
        public bool IsActive { get; set; }
        public int CreatedByID { get; set; }
        public DateTime CreatedDate { get; set; }
        public int ModifiedByID { get; set; }
        public DateTime ModifiedDate { get; set; }        
    }
}
