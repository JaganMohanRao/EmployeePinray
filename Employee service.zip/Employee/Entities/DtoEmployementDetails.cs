﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entities
{
    public class DtoEmployementDetails
    {
        public DtoEmployementDetails()
        {

        }

        public int EmployementDetailID { get; set; }
        public int EmployeeID { get; set; }
        public string CompanyName { get; set; }
        public string Address { get; set; }
        public string City { get; set; }
        public int PinCode { get; set; }
        public string Website { get; set; }
        public string LandlineNumber { get; set; }
        public string EmployeeNumber { get; set; }
        public string Designation { get; set; }
        public string Department { get; set; }
        public DateTime JoiningDate { get; set; }
        public DateTime RelievingDate { get; set; }
        public bool IsFullTimeEmployee { get; set; }
        public decimal NetMonthlySalary { get; set; }
        public string ManagerName { get; set; }
        public string ManagerDesignation { get; set; }
        public string ManagerContactNumber { get; set; }
        public string ManagerEmailID { get; set; }
        public string HrManagerName { get; set; }
        public string HrContactNumber { get; set; }
        public string HrEmailID { get; set; }
        public string OfferLetterAttachment { get; set; }
        public string RelievingLetterAttachment { get; set; }
        public string ExperienceCertificateAttachment { get; set; }
        public string Payslip1Attachment { get; set; }
        public string Payslip2Attachment { get; set; }
        public string Payslip3Attachment { get; set; }
        public int? CreatedByID { get; set; }
        public DateTime? CreateDate { get; set; }
        public int? ModifiedByID { get; set; }
        public DateTime? ModifiedDate { get; set; }
    }
}
