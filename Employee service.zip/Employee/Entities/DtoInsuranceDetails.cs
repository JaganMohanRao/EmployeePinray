﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entities
{
    public enum RelationshipType
    {
        Self = 1,
        Spouse = 2,
        Child1 = 3,
        Child2 = 4
    }

    public class DtoInsuranceDetails
    {
        public DtoInsuranceDetails()
        {

        }

        public int InsuranceDetailID { get; set; }
        public int EmployeeID { get; set; }
        public RelationshipType RelationshipWithInsurerType { get; set; }
        public string Name { get; set; }
        public string Gender { get; set; }
        public Int32 MobileNumber { get; set; }
        public DateTime DateOfBirth { get; set; }
        public int RelationshipWithProposer { get; set; }
        public string MaritalStatus { get; set; }
        public bool IsActive { get; set; }
        public int CreatedByID { get; set; }
        public DateTime CreateDate { get; set; }
        public int? ModifiedByID { get; set; }
        public DateTime? ModifiedDate { get; set; }
    }
}
