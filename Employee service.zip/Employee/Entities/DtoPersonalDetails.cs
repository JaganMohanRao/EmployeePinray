﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entities
{
    public class DtoPersonalDetails
    {
        public DtoPersonalDetails()
        {

        }

        public int PersonalDetailID { get; set; }
        public int EmployeeID { get; set; }
        public string NameAsPerAADHAAR { get; set; }
        public string FatherName { get; set; }
        public DateTime DateOfBirth { get; set; }
        public Int64 MobileNumber { get; set; }
        public string PanNumber { get; set; }
        public string PanAttachment { get; set; }
        public string PassportNumber { get; set; }
        public string PassportAttachment { get; set; }
        public string AadhaarNumber { get; set; }
        public string AadhaarAttachment { get; set; }
        public int? CreatedByID { get; set; }
        public DateTime CreateDate { get; set; }
        public int ModifiedByID { get; set; }
        public DateTime ModifiedDate { get; set; }
    }
}
